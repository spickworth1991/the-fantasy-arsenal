"use client";

import TradeAnalyzer from "./TradeAnalyzer";

export default function TradeClient() {
  return <TradeAnalyzer />;
}
