import { NextResponse } from "next/server";
import { buildPushPayload } from "@block65/webcrypto-web-push";

function getDb() {
  return process.env.PUSH_DB;
}

function assertAuth(req) {
  const secret = req.headers.get("x-push-secret");
  return !!process.env.PUSH_ADMIN_SECRET && secret === process.env.PUSH_ADMIN_SECRET;
}

function getVapid() {
  const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT;
  if (!publicKey || !privateKey || !subject) throw new Error("Missing VAPID env vars.");
  return { subject, publicKey, privateKey };
}

async function getPickCount(draftId) {
  const res = await fetch(`https://api.sleeper.app/v1/draft/${draftId}/picks`);
  if (!res.ok) throw new Error(`Sleeper picks fetch failed: ${draftId}`);
  const picks = await res.json();
  return Array.isArray(picks) ? picks.length : 0;
}

export async function POST(req) {
  try {
    if (!assertAuth(req)) return new NextResponse("Unauthorized", { status: 401 });

    const db = getDb();
    if (!db?.prepare) return new NextResponse("PUSH_DB binding not found.", { status: 500 });

    const vapid = getVapid();
    const now = Date.now();

    // load all subscriptions
    const subRows = await db
      .prepare(`SELECT endpoint, subscription_json, draft_ids_json FROM push_subscriptions`)
      .all();

    const subs = (subRows?.results || []).map((r) => {
      let sub = null;
      let draftIds = [];
      try { sub = JSON.parse(r.subscription_json); } catch {}
      try { draftIds = JSON.parse(r.draft_ids_json || "[]"); } catch {}
      return { endpoint: r.endpoint, sub, draftIds: Array.isArray(draftIds) ? draftIds : [] };
    }).filter((x) => x.sub && x.sub.endpoint);

    let sent = 0;

    for (const s of subs) {
      for (const draftId of s.draftIds) {
        // current pick count
        const pickCount = await getPickCount(draftId);

        // last known pick count for this subscription+draft
        const state = await db.prepare(
          `SELECT last_pick_count FROM push_draft_state WHERE endpoint=? AND draft_id=?`
        ).bind(s.endpoint, String(draftId)).first();

        const lastPickCount = state?.last_pick_count ?? 0;

        if (pickCount > lastPickCount) {
          // update state first (prevents duplicates if sending fails mid-run)
          await db.prepare(
            `INSERT INTO push_draft_state (endpoint, draft_id, last_pick_count, updated_at)
             VALUES (?, ?, ?, ?)
             ON CONFLICT(endpoint, draft_id) DO UPDATE SET
               last_pick_count=excluded.last_pick_count,
               updated_at=excluded.updated_at`
          ).bind(s.endpoint, String(draftId), pickCount, now).run();

          // send notification
          const msg = {
            data: JSON.stringify({
              title: "Draft Pick Tracker",
              body: `New pick made (total picks: ${pickCount}). Tap to open.`,
              url: `/draft-pick-tracker`,
            }),
            options: { ttl: 60 },
          };

          const payload = await buildPushPayload(msg, s.sub, vapid);
          const res = await fetch(s.sub.endpoint, payload);

          if (res.ok) sent += 1;
        }
      }
    }

    return NextResponse.json({ ok: true, sent });
  } catch (e) {
    return new NextResponse(e?.message || "Poll failed", { status: 500 });
  }
}
